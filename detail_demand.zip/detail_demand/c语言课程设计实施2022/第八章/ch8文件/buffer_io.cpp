#include <stdio.h>
#include<stdlib.h>
int main(){
	char s[100];
	int i,n=0;
	FILE *fp;

	while((s[n]=getchar())!='\n'){
		s[n]=s[n]-'a'+'A';
		putchar(s[n]);
		n++;
	}
	printf("\n");
	fp=fopen("e:\\chars.txt","w");
	for(i=0;i<n;i++){
		fprintf(fp,"%c",s[i]);
		//fflush(fp);//ǿ��д��
	}
	fputs("hello",fp);
	system("pause");
	fclose(fp);
	return 0;
}
