#include <stdio.h>
int main()
{
	int a,b;
	scanf("%d%d",&a,&b);
	printf("%*d\n",b+2,a);
	char a1[80];
	scanf("%*2s%s",a1);
	printf("%s",a1);
	
	return 0;
}
